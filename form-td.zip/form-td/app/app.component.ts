import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms'; // 3rd step

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  @ViewChild('f', { static: false }) signupForm: NgForm; // 4th step
  defaultQuestion = 'teacher';
  answer = '';
  genders = ['male', 'female'];
  user = {
    username: 'Mohit',
    email: '',
    secretQuestion: '',
    answer: '',
    gender: ''
  };
  
  submitted = false;

  ngAfterViewInit() {
    setTimeout(() => {
      this.signupForm.setValue({
        userData: {
          username: "Mohit",
          email: ''
        },
        secret: 'pet',
        questionAnswer: '',
        gender: 'male'
      });  
    }, 0);
  }

  suggestUserName() {
    const suggestedName = 'Superuser';
    this.signupForm.form.patchValue({
      userData: {
        username: suggestedName
      }
    });
  }

  // onSubmit(form: NgForm) {
  //   console.log(form);
  // }

  onSubmit() {
    this.submitted = true;
    this.user.username = this.signupForm.value.userData.username;
    this.user.email = this.signupForm.value.userData.email;
    this.user.secretQuestion = this.signupForm.value.secret;
    this.user.answer = this.signupForm.value.questionAnswer;
    this.user.gender = this.signupForm.value.gender;

    this.signupForm.reset();
  }
}
